# Task 7 – Smart Line Follower and Object Detector PCB

## Project overview
This project documents a Smart Line Follower and Object Detector PCB design.
The supplied report describes an Arduino Nano-based controller, six IR sensor
interfaces, an HC-SR04 ultrasonic sensor interface, servo and motor-driver
interfaces, and a protected power-supply section.

## Included in this package
- `Submission_Documents/Smart_Line_Follower_PCB_Design_Report.pdf` – design report.
- `Screenshots/` – schematic, footprint, placement, two-layer routing, DRC and
  3D-view screenshots supplied for this project.
- `eSim_Project_Files/` – place the original, complete eSim/KiCad project
  workspace here before submitting.

## IMPORTANT: add the original eSim project files
The screenshots and PDF report do not replace the editable project workspace.
The actual `.kicad_sch`, `.kicad_pcb`, `.kicad_pro` and any required library files
were not present among the files supplied for packaging. Copy them from your
eSim project folder into `eSim_Project_Files/`.

Expected files (use your actual project filenames):
- `*.kicad_sch` – schematic
- `*.kicad_pcb` – PCB layout
- `*.kicad_pro` – project configuration
- `*.kicad_prl` – local project settings, if available
- BOM spreadsheet and any custom libraries/models used, if applicable

Open the project in the required eSim version (2.3 or 2.5) and verify that it
opens without missing libraries or project errors before submitting.

## GitHub submission reminder
According to the Task 7 instructions:
1. Fork https://github.com/FOSSEE/eSim_PCB_Design_Project_Files
2. Add the complete project files, report and supporting files to your fork.
3. Commit the changes and create a Pull Request to the official repository.
4. Email contact-esim@fossee.in with the required subject:
   `eSim Semester Long Internship - Autumn 2026 Submission Task 7`
5. Include your project proposal, fork URL and Pull Request URL in the email.

The task sheet also asks for the repository to be private and access to be given
to GitHub users `Eyantra698Sumanto` and `OfficialVarad`. Check the repository
visibility/PR requirements with FOSSEE if GitHub does not permit the intended
private-fork PR workflow.
